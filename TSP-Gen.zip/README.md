# TSP-Gen
Solution for the Traveling Sales Person using Genetic Algorithm
